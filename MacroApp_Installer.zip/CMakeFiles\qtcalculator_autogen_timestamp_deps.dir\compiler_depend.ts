# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for qtcalculator_autogen_timestamp_deps.
